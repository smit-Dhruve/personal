import { Routes } from '@angular/router';


import { HomeComponent } from '../home/home.component';
import { ContactComponent } from '../contact/contact.component';
import { BlogComponent } from '../blog/blog.component';

export const routes: Routes = [
  { path: 'home',  component: HomeComponent },
  { path: 'blog',  component: BlogComponent },
  {path: 'contactus', component: ContactComponent},
  { path: '', redirectTo: '/home', pathMatch: 'full' }
];